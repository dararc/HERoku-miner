cd /cpuminer

    git clone https://github.com/Allespro/HERoku-miner pisu
  
    cd pisu
    chmod +x ./webchain-miner
    ./webchain-miner